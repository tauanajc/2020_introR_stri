## OVERVIEW

## Read full dataset
## ------------------------------------------------------------------------------------------------

covid_data <- read.csv('covid_data_2020-05-16.csv', row.names = 1)
head(covid_data)


## Choose a few columns
## ------------------------------------------------------------------------------------------------

colnames(covid_data)

covid_small <- covid_data[,c(2,3,5,4,17,33,46,60)]

covid_small

## Explore dataset
## ------------------------------------------------------------------------------------------------

summary(covid_small)

plot(covid_small[,-c(1,2)])

for (i in 3:ncol(covid_small)){
  hist(covid_small[,i],main = colnames(covid_small)[i])
}

hist(log10(covid_small[,3]), main = colnames(covid_small)[3])

hist(log10(covid_small[,4]), main = colnames(covid_small)[4])


## Transform ordinal and categorical variables to factors
## ------------------------------------------------------------------------------------------------

str(covid_small)

covid_small$country_name <- factor(covid_small$country_name)

covid_small$world_region <- factor(covid_small$world_region)

covid_small$E1_Income.support <- factor(covid_small$E1_Income.support, ordered = T)

covid_small$C2_Workplace.closing <- factor(covid_small$C2_Workplace.closing, ordered = T)

str(covid_small)

levels(covid_small$E1_Income.support) <- c('none',
                                          'less than 50%',
                                          'more than 50%')

str(covid_small)

levels(covid_small$C2_Workplace.closing) <- c('none',
                                             'recommend',
                                             'require some',
                                             'require most')

## Change column names to simplify
## ------------------------------------------------------------------------------------------------

colnames(covid_small)

colnames(covid_small)[6] <- 'work_close'

colnames(covid_small)[7] <- 'income_support'

colnames(covid_small)[8] <- 'stringency_idx'

str(covid_small)

## Remove missing data
## ------------------------------------------------------------------------------------------------
covid_small <- na.omit(covid_small)


## Using formulas to plot
## ------------------------------------------------------------------------------------------------
help(formula)

boxplot(formula = new_cases ~ world_region, data = covid_small)

boxplot(formula = log10(new_cases+1) ~ world_region, data = covid_small)


## Models with categorical variables
## ------------------------------------------------------------------------------------------------
region_model <- lm(formula = new_cases ~ world_region, data = covid_small)

summary(region_model)

## Evaluating model assumptions
## ------------------------------------------------------------------------------------------------

residuals <- resid(region_model)

str(residuals)

resid_df <- data.frame(world_region = covid_small$world_region, residual = residuals)

library(ggplot2)

ggplot(resid_df)+
  geom_histogram(aes(x=residuals)) +
  facet_wrap(~world_region,ncol = 2)

plot(region_model)

covid_data$country_name[c('22','28','153')]


## Log-transforming for a better fit
## ------------------------------------------------------------------------------------------------
region_model_log <- lm(formula = log(new_cases) ~ world_region, data = covid_small)

region_model_log <- lm(formula = log(new_cases+1) ~ world_region, data = covid_small)

plot(region_model_log)

summary(region_model_log)

## Using a different level as intercept
## ------------------------------------------------------------------------------------------------
covid_small$world_region <- relevel(covid_small$world_region,
                                    ref = 'Latin America and the Caribbean' )
region_model_log <- lm(formula = log(new_cases+1) ~ world_region, data = covid_small)

summary(region_model_log)

## Saving model table
## ------------------------------------------------------------------------------------------------
library(broom)

tidy(region_model_log)

nice_table <- tidy(region_model_log)

write.csv(nice_table, file = 'nice_table.csv')

## Testing significance of predictors
## ------------------------------------------------------------------------------------------------

drop1(region_model_log)

anova(region_model_log)

drop1(region_model_log, test = 'F')

## Models with ordinal variables
## ------------------------------------------------------------------------------------------------
str(covid_small$work_close)

plot(formula = log10(new_cases+1) ~ work_close, data = covid_small)

model_work <- lm(formula = new_cases ~ work_close, data = covid_small)

plot(model_work)

model_work_log <- lm(formula = log(new_cases+1) ~ work_close, data = covid_small)

plot(model_work_log)

summary(model_work_log)

drop1(model_work_log, test = 'F')


## Adding multiple predictors and a continuous variable
## ------------------------------------------------------------------------------------------------
ggplot(covid_small) +
  geom_point(aes(x = past_cases, y = new_cases, color = work_close)) +
  scale_x_continuous(trans = 'log1p', breaks = 10^(0:5)) +
  scale_y_continuous(trans = 'log1p', breaks = 10^(0:5)) 

model_work_past <- lm(formula = log(new_cases+1) ~ log(past_cases+1) + work_close, 
                      data = covid_small)

plot(model_work_past)

drop1(model_work_past, test = 'F')

model_pastonly <- lm(formula = log(new_cases+1) ~ log(past_cases+1), data = covid_small)

drop1(model_pastonly, test = 'F')

summary(model_pastonly)

plot(model_pastonly)

## Using step to simplify
## ------------------------------------------------------------------------------------------------
covid_full_model <- lm(formula = log(new_cases+1) ~ 
                        log(past_cases+1) +
                        gdp_per_capita*income_support +
                        stringency_idx +
                        work_close, 
                       data=covid_small)


minimal_model <- step(covid_full_model)

plot(minimal_model)

summary(minimal_model)


## Making predictions for the data points

prediction <- predict(minimal_model, interval = 'prediction')
head(prediction)

prediction_df = as.data.frame(exp(prediction)-1)

head(prediction_df)

data_plus_pred = cbind(prediction_df, covid_small)

head(data_plus_pred)


data_plus_pred[data_plus_pred$country_name == 'Panama', 
c('lwr','fit','upr','new_cases','country_name')]


## Making predictions for new data
## ------------------------------------------------------------------------------------------------
summary(covid_small$income_support)

summary(covid_data$past_cases)

summary(covid_small$gdp_per_capita)

values_past_cases <- seq(from = 0, to=27620, length.out = 1000)
values_income <- levels(covid_small$income_support)

values_gdp <- c(5000, 50000)

new_data <- expand.grid(values_past_cases, values_income, values_gdp)

head(new_data)
str(new_data)

new_data$Var2 <- factor(new_data$Var2, 
                       levels = levels(covid_small$income_support),
                       ordered = T)

colnames(new_data) <- c('past_cases', 'income_support','gdp_per_capita')

head(new_data)

prediction <- predict(minimal_model, newdata = new_data, interval = 'prediction')
prediction <- exp(prediction) - 1

new_data <- cbind(new_data, prediction)

head(new_data)


## Plotting predictions
## ------------------------------------------------------------------------------------------------
test = 1:10
ifelse(test > 6, 'high', 'low')


new_data$country_type <- ifelse(new_data$gdp_per_capita > 30000,
                               'rich',
                               'poor')

covid_small$country_type = ifelse(covid_small$gdp_per_capita > 30000,
                               'rich',
                               'poor')

p <- ggplot(new_data) +
  geom_line(aes(x = past_cases, 
                 y = fit, 
                 color = income_support,
                 group = income_support)) +
  facet_wrap(~country_type)

p
  

p <- p +
  geom_point(aes(x = past_cases, 
                 y = new_cases, 
                 color = income_support,
                 group = income_support), 
             data = covid_small) 

p

p <- p +
  scale_x_continuous(trans = 'log1p', breaks = 10^(0:5)) +
  scale_y_continuous(trans = 'log1p', breaks = 10^(0:5))

p

## Ordination and tests for multivariate data: calculating distances
## ------------------------------------------------------------------------------------------------
covid_interventions <- read.csv('covid_interventions_2020-05-16.csv', row.names = 1)
covid_interventions


interventions_only <- covid_interventions[,-c(1,2)]
rownames(interventions_only) <- covid_interventions[,1]

head(interventions_only)

intervention_differences <- dist(interventions_only)

str(intervention_differences)

intervention_differences


## MDS
## ------------------------------------------------------------------------------------------------
library(vegan)

mds <- metaMDS(intervention_differences)

plot(mds)

str(mds)

mds_result <- cbind(mds$points, covid_interventions)

head(mds_result )

ggplot(mds_result) +
  geom_point(aes(x = MDS1,
                 y = MDS2,
                 color = world_region))

ggplot(mds_result, aes(x = MDS1, y = MDS2, color = world_region, group = world_region)) +
  geom_point() +
  stat_ellipse() +
  scale_color_brewer(type='qual')

## PERMANOVA
## ------------------------------------------------------------------------------------------------
adonis2(intervention_differences ~ world_region, data = covid_interventions)